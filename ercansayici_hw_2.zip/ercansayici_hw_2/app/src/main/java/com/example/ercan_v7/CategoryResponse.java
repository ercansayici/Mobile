package com.example.ercan_v7;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.telecom.Call;
import android.widget.ArrayAdapter;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.ArrayList;
import javax.security.auth.callback.Callback;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class CategoryResponse implements Callback {
    public int srvMsgCd;
    public String srvMsgTxt;
    public ArrayList<Category> items = new ArrayList<>();

    public transient ArrayList<String> categoryNames;
    public transient AppCompatActivity activity;
    public transient ArrayAdapter<String> adapter;

    CategoryResponse(ArrayList<String> categoryNames, AppCompatActivity activity, ArrayAdapter<String> adapter) {
        this.categoryNames = categoryNames;
        this.activity = activity;
        this.adapter = adapter;
    }

    public void onFailure(Call call, IOException e) {
        e.printStackTrace();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    public void onResponse(Call call, Response response) throws IOException {
        try (ResponseBody responseBody = response.body()) {
            Gson gson = new Gson();
            CategoryResponse categoryResponse = gson.fromJson(responseBody.string(), CategoryResponse.class);
            this.srvMsgCd = categoryResponse.srvMsgCd;
            this.srvMsgTxt = categoryResponse.srvMsgTxt;
            this.items.clear();
            Category all = new Category();
            all.categoryName = "All";
            all.categoryID = -1;
            this.items.add(all);
            this.items.addAll(categoryResponse.items);
            this.categoryNames.clear();
            this.categoryNames.addAll(getCategoryNames());
        }
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                adapter.notifyDataSetChanged();
            }
        });
    }
    ArrayList<String> getCategoryNames() {
        ArrayList<String> result = new ArrayList<>();
        for (int i=0; i<items.size(); i++) {
            result.add(i, items.get(i).categoryName);
        }
        return result;
    }
}
