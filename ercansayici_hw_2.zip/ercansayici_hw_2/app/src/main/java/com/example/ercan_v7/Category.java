package com.example.ercan_v7;

public class Category {


    String categoryName;
    int categoryID;
}
