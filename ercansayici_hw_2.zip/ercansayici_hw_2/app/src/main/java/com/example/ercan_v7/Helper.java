package com.example.ercan_v7;

import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;

public class Helper {

    public static void getAllNewsCategories(CategoryResponse categoryResponse) {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url("http://94.138.207.51:8080/NewsApp/service/news/getallnewscategories").build();
        client.newCall(request).enqueue((Callback) categoryResponse);
    }

    public static void getAllNews(int categoryId, NewsResponse newsResponse) {
        OkHttpClient client = new OkHttpClient();
        Request.Builder requestBuilder = new Request.Builder();
        if (categoryId == -1) {requestBuilder.url("http://94.138.207.51:8080/NewsApp/service/news/getall");}
        else {requestBuilder.url("http://94.138.207.51:8080/NewsApp/service/news/getbycategoryid/" + categoryId);}
        Request request = requestBuilder.build();
        client.newCall(request).enqueue((Callback) newsResponse);
    }

    public static void getNewsById(int id, NewsResponse newsResponse) {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url("http://94.138.207.51:8080/NewsApp/service/news/getnewsbyid/" + id).build();
        client.newCall(request).enqueue((Callback) newsResponse);
    }

    public static void getImageBitmapFromUrl(String url, Callback callback) {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(url).build();
        client.newCall(request).enqueue(callback);
    }


}
