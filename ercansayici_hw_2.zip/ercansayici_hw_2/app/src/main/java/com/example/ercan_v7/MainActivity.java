package com.example.ercan_v7;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public NewsResponse allNews;
    public CategoryResponse allCategories;
    public ArrayList<String> categoryNames;
    public int chosenCategoryId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner1);
        categoryNames = new ArrayList<>();
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item, categoryNames);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);
        allCategories = new CategoryResponse(categoryNames, this, spinnerAdapter);
        Helper.getAllNewsCategories(allCategories);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                chosenCategoryId = allCategories.items.get(position).categoryID;
                Helper.getAllNews(chosenCategoryId, allNews);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                Helper.getAllNews(chosenCategoryId, allNews);
            }
        });

        ProgressBar progressBar = findViewById(R.id.pbar1);
        progressBar.setVisibility(View.VISIBLE);
        allNews = new NewsResponse(progressBar, this);
        NewsArrayAdapter adapter = new NewsArrayAdapter(this, allNews.items);
        allNews.setAdapter(adapter);
        ListView listView = findViewById(R.id.news_list_view);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
                Intent myIntent = new Intent(view.getContext(), NewsItemActivity.class);
                myIntent.putExtra("NEWS_ID", allNews.items.get(position).getId());
                startActivity(myIntent);
            }
        });

    }
}
