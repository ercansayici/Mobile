package com.example.ercan_v7;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class NewsArrayAdapter extends ArrayAdapter<NewsItem> {
    public NewsArrayAdapter(Context context, List<NewsItem> newsList) {
        super(context, 0, newsList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        NewsItem item = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }
        ImageView image = convertView.findViewById(R.id.listview_image);
        ImageResponse imageResponse = new ImageResponse(image, (AppCompatActivity) convertView.getContext());
        Helper.getImageBitmapFromUrl(item.getImage(), imageResponse);

        TextView headline = convertView.findViewById(R.id.listview_item_title);
        headline.setText(item.getTitle());

        TextView date = convertView.findViewById(R.id.listview_item_date);
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
        String strDate = dateFormat.format(new Date(Long.valueOf(item.getDate())));
        date.setText(strDate);

        return convertView;
    }
}
