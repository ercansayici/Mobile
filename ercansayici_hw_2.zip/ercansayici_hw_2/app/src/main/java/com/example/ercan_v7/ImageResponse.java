package com.example.ercan_v7;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class ImageResponse implements Callback {
    public ImageView view;
    public AppCompatActivity activity;
    private Bitmap bitmap;

    ImageResponse(ImageView view, AppCompatActivity activity) {
        this.view = view;
        this.activity = activity;
    }

    public void onFailure(Call call, IOException e) {
        e.printStackTrace();
    }

    public void onResponse(Call call, Response response) {
        InputStream inputStream = response.body().byteStream();
        this.bitmap = BitmapFactory.decodeStream(inputStream);
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (bitmap != null) {
                    view.setImageBitmap(bitmap);
                }
            }
        });
    }
}
