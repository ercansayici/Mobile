package com.example.ercan_v7;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NewsItemActivity extends AppCompatActivity {
    public int newsId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listitem);

        Intent myIntent = getIntent();
        newsId = myIntent.getIntExtra("NEWS_ID", 0);
        ProgressBar progressBar = findViewById(R.id.my_activity_listitem_bar);
        progressBar.setVisibility(View.VISIBLE);
        NewsResponse newsResponse = new NewsResponse(progressBar, this);
        Helper.getNewsById(newsId, newsResponse);
        while (true) {
            if (newsResponse.items.size() != 0) {
                break;
            }
        }
        NewsItem item = newsResponse.items.get(0);
        TextView titleView = findViewById(R.id.item_activity_title);
        titleView.setText(item.getTitle());
        TextView dateView = findViewById(R.id.item_activity_date);
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
        String strDate = dateFormat.format(new Date(Long.valueOf(item.getDate())));
        dateView.setText(strDate);

        ImageView photoView = findViewById(R.id.item_activity_image);
        ImageResponse imageResponse = new ImageResponse(photoView, this);
        Helper.getImageBitmapFromUrl(item.getImage(), imageResponse);
        TextView contentView = findViewById(R.id.item_activity_content);
        contentView.setText(item.getText());

        Button homeButton = findViewById(R.id.h_btn);
        homeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent myIntent = new Intent(v.getContext(), MainActivity.class);
                myIntent.setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP );
                startActivity(myIntent);
            }
        });


    }
}
