package com.example.ercan_v7;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.telecom.Call;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;

import javax.security.auth.callback.Callback;


import okhttp3.Response;
import okhttp3.ResponseBody;

public class NewsResponse implements Callback {
    public int serviceMessageCode;
    public String serviceMessageText;
    public ArrayList<NewsItem> items = new ArrayList<>();

    public transient ProgressBar progressBar;
    public transient AppCompatActivity activity;
    public transient ArrayAdapter<NewsItem> adapter;

    public void setAdapter(ArrayAdapter<NewsItem> adapter) {
        this.adapter = adapter;
    }

    NewsResponse(ProgressBar progressBar, AppCompatActivity activity){
        this.progressBar = progressBar;
        this.activity = activity;
    }

    public void onFailure(Call call, IOException e) {
        e.printStackTrace();
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void onResponse(Call call, Response response) throws IOException {
        try (ResponseBody responseBody = response.body()) {
            Gson gson = new Gson();
            NewsResponse newsResponse = gson.fromJson(responseBody.string(), NewsResponse.class);
            this.serviceMessageCode = newsResponse.serviceMessageCode;
            this.serviceMessageText = newsResponse.serviceMessageText;
            this.items.clear();
            this.items.addAll(newsResponse.items);
        }
        this.activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.GONE);
                if (adapter != null) {
                    adapter.notifyDataSetChanged();
                }
            }
        });

    }
}
