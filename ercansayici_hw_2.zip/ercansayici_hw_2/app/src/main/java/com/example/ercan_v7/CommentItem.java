package com.example.ercan_v7;

/**
 * Created by atanaltay on 28/03/2017.
 */

public class CommentItem {

    private int news_id;
    private String name;
    private String text;

    public CommentItem() {
    }



    public CommentItem(int newsId, String name, String text) {
        this.name = name;
        this.text = text;
        this.news_id = newsId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
    public int getNews_id() {
        return news_id;
    }

    public void setNews_id(int news_id) {
        this.news_id = news_id;
    }
}
